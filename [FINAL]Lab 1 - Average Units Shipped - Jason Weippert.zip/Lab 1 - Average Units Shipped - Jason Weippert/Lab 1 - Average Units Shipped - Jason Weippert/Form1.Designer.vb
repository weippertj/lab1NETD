﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAverageUnitsShipped
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblUnits = New System.Windows.Forms.Label()
        Me.lblAverage = New System.Windows.Forms.Label()
        Me.lblDay = New System.Windows.Forms.Label()
        Me.ttipUserInputFlow = New System.Windows.Forms.ToolTip(Me.components)
        Me.txtUserInput = New System.Windows.Forms.TextBox()
        Me.btnEnter = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.txtUnitOutput = New System.Windows.Forms.TextBox()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblUnits
        '
        Me.lblUnits.Location = New System.Drawing.Point(46, 34)
        Me.lblUnits.Name = "lblUnits"
        Me.lblUnits.Size = New System.Drawing.Size(41, 23)
        Me.lblUnits.TabIndex = 0
        Me.lblUnits.Text = "&Units:"
        Me.lblUnits.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ttipUserInputFlow.SetToolTip(Me.lblUnits, "Label for the Unit's that the user enters.")
        '
        'lblAverage
        '
        Me.lblAverage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAverage.Location = New System.Drawing.Point(56, 225)
        Me.lblAverage.Name = "lblAverage"
        Me.lblAverage.Size = New System.Drawing.Size(220, 23)
        Me.lblAverage.TabIndex = 4
        Me.lblAverage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ttipUserInputFlow.SetToolTip(Me.lblAverage, "Output label, displays the average from the seven values entered into the output " &
        "box above")
        '
        'lblDay
        '
        Me.lblDay.Location = New System.Drawing.Point(234, 32)
        Me.lblDay.Name = "lblDay"
        Me.lblDay.Size = New System.Drawing.Size(42, 23)
        Me.lblDay.TabIndex = 2
        Me.lblDay.Text = "&Day: 1"
        Me.lblDay.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ttipUserInputFlow.SetToolTip(Me.lblDay, "Day label that moves until the value of Day 7 throughout the shipment value input" &
        "s.")
        '
        'txtUserInput
        '
        Me.txtUserInput.Location = New System.Drawing.Point(106, 34)
        Me.txtUserInput.Name = "txtUserInput"
        Me.txtUserInput.Size = New System.Drawing.Size(126, 20)
        Me.txtUserInput.TabIndex = 1
        Me.ttipUserInputFlow.SetToolTip(Me.txtUserInput, "User input box, user inputs a number for validation and processing")
        '
        'btnEnter
        '
        Me.btnEnter.Location = New System.Drawing.Point(12, 251)
        Me.btnEnter.Name = "btnEnter"
        Me.btnEnter.Size = New System.Drawing.Size(75, 23)
        Me.btnEnter.TabIndex = 5
        Me.btnEnter.Text = "&Enter"
        Me.ttipUserInputFlow.SetToolTip(Me.btnEnter, "Enter button, when pressed it can perform the calculations from input to output, " &
        "can also be pressed by pressing the 'Enter' key")
        Me.btnEnter.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnReset.Location = New System.Drawing.Point(124, 251)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(75, 23)
        Me.btnReset.TabIndex = 6
        Me.btnReset.Text = "&Reset"
        Me.ttipUserInputFlow.SetToolTip(Me.btnReset, "Reset button, resets all values and logic of the form, can be pressed manually or" &
        " pressed by pressing the 'Escape' key.")
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'txtUnitOutput
        '
        Me.txtUnitOutput.Location = New System.Drawing.Point(56, 60)
        Me.txtUnitOutput.Multiline = True
        Me.txtUnitOutput.Name = "txtUnitOutput"
        Me.txtUnitOutput.ReadOnly = True
        Me.txtUnitOutput.Size = New System.Drawing.Size(220, 149)
        Me.txtUnitOutput.TabIndex = 8
        Me.ttipUserInputFlow.SetToolTip(Me.txtUnitOutput, "User output box, whatever is entered into the input box is outputted here, can ho" &
        "ld up to seven values before calculating sum and average")
        '
        'btnExit
        '
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnExit.Location = New System.Drawing.Point(234, 251)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 7
        Me.btnExit.Text = "&Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'frmAverageUnitsShipped
        '
        Me.AcceptButton = Me.btnEnter
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnReset
        Me.ClientSize = New System.Drawing.Size(321, 286)
        Me.Controls.Add(Me.txtUnitOutput)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnEnter)
        Me.Controls.Add(Me.txtUserInput)
        Me.Controls.Add(Me.lblDay)
        Me.Controls.Add(Me.lblAverage)
        Me.Controls.Add(Me.lblUnits)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmAverageUnitsShipped"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Average Units Shipped"
        Me.ttipUserInputFlow.SetToolTip(Me, "Form for the program")
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblUnits As Label
    Friend WithEvents lblAverage As Label
    Friend WithEvents lblDay As Label
    Friend WithEvents ttipUserInputFlow As ToolTip
    Friend WithEvents txtUserInput As TextBox
    Friend WithEvents btnEnter As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents txtUnitOutput As TextBox
End Class
