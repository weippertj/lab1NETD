﻿'Name: Jay Weippert
'Date: 01/25/2019
'Description of the Program: This program is a Visual Basic Form that calculates the average among 7 input variables that are stored in an integer array, the range of input box is 0-1000 and must be a whole number.

Public Class frmAverageUnitsShipped
    Dim dayCounter As Integer = 0
    Dim shipmentValues(6) As Integer 'Declares the array for the shipment values
    Dim sum As Integer = 0
    Dim numInput As Integer
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnEnter.Click

        'INPUT
        If IsNumeric(txtUserInput.Text) = True Then 'Does numerical input checking
            Integer.TryParse(txtUserInput.Text, numInput) 'Tryparses Integer Value
            If numInput < 0 Or numInput > 1000 Then 'If Input Range is Invalid
                MsgBox("Please enter a value between 0 and 1000") 'The range of the acceptable values
            Else
                txtUserInput.Text = "" 'If it passes, txt returns to ""
                txtUnitOutput.Text += numInput.ToString & vbCrLf 'New line in textbox to format the textbox inputs
                shipmentValues(dayCounter) = numInput 'shipmentValues index is bound to the dayCounter, takes input/numbers from the Inputbox.
                lblDay.Text = "Day: " + (dayCounter + 2).ToString 'day label changes along with the counter counting
                dayCounter += 1 'daycounter counts +1
            End If
        Else
            MsgBox("Enter a whole number.") 'If the tryparse fails, enter a whole number.
        End If


        If dayCounter > 6 Then 'if dayCounter is 6 (7 values in total are inputted, execute the loop to calculate the sum below)
            For Each value As Integer In shipmentValues 'Loop for every value in shipmentValues (which is 0-6), add them to the value of sum
                sum += value 'calculate sum
            Next
            lblAverage.Text = "The weekly average is: " & Math.Round(sum / 7, 2) 'Output message
            btnEnter.Enabled = False 'Disable btnEnter
            lblDay.Text = "Day: 7"
            txtUserInput.Enabled = False 'Disable txtUserInput
        End If
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub lstDays_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        btnEnter.Enabled = True
        txtUserInput.Enabled = True
        txtUserInput.Clear()
        txtUnitOutput.Clear()
        lblAverage.Text = ""
        lblDay.Text = "Day 1"
        dayCounter = 0
        txtUserInput.Focus()
    End Sub
End Class
